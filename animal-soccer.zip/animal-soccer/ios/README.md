# 🦊 Animal Soccer — iOS controller (SwiftUI)

A native phone controller. It reads CoreMotion (tilt to aim, flick to shoot) and
talks to the Mac server over a plain WebSocket on port **3001**. Real haptics on
goals. Requires a Mac with Xcode and an iPhone.

## Files

- `AnimalSoccer/AnimalSoccerApp.swift` — app entry
- `AnimalSoccer/ContentView.swift` — themed UI, animal picker, tilt meter, haptics
- `AnimalSoccer/MotionManager.swift` — CoreMotion: aim + flick detection
- `AnimalSoccer/WebSocketClient.swift` — URLSessionWebSocketTask client

## Create the Xcode project (≈5 min)

1. **Xcode ▸ File ▸ New ▸ Project… ▸ iOS ▸ App.**
   - Product Name: `AnimalSoccer`
   - Interface: **SwiftUI**, Language: **Swift**
2. Delete the auto-generated `ContentView.swift` and the `…App.swift`, then drag
   the four files from this `AnimalSoccer/` folder into the project
   (check *Copy items if needed*).
3. Select the project ▸ your target ▸ **Signing & Capabilities** ▸ set **Team** to
   your Apple ID (a free account is fine).

## Required permissions (Info / Info.plist)

In the target's **Info** tab, add these keys (or paste into `Info.plist`):

```xml
<key>NSMotionUsageDescription</key>
<string>Used to aim and kick by tilting and flicking your phone.</string>

<key>NSLocalNetworkUsageDescription</key>
<string>Connects to the game running on your Mac over your local Wi-Fi.</string>

<!-- allow the plain ws:// connection to your Mac on the LAN -->
<key>NSAppTransportSecurity</key>
<dict>
    <key>NSAllowsLocalNetworking</key>
    <true/>
</dict>
```

> Without `NSAllowsLocalNetworking`, iOS blocks the non-TLS `ws://` connection.
> Without `NSMotionUsageDescription`, the app crashes when starting motion.
> Without `NSLocalNetworkUsageDescription`, iOS 14+ blocks the LAN connection
> (you'll get a one-time "allow local network" prompt the first run).

## Run it

1. Start the server on your Mac (`npm start` in the project root) and open the
   big screen at `https://localhost:3000`.
2. Plug in your iPhone, pick it as the run destination, press **▶ Run**.
   (First time on a free account: on the phone, *Settings ▸ General ▸ VPN & Device
   Management ▸ Trust* your developer certificate. Free certs expire after 7 days —
   just re-run from Xcode to refresh.)
3. In the app, type the **Mac's IP address** shown in Terminal / on the big screen
   (e.g. `192.168.1.24`). Port 3001 is used automatically.
4. Pick your animal ▸ **Start playing** ▸ allow Motion + Local Network ▸ tilt to
   aim, flick to shoot. Use **Re-center aim** anytime to recalibrate neutral.

## Tuning

In `MotionManager.swift`:
- `tiltRange` — radians of roll for full left/right deflection (smaller = more sensitive)
- `kickThreshold` — g-force needed to register a flick (lower = easier shots)
- `kickCooldown` — minimum seconds between shots
