import SwiftUI
import CoreMotion
import UIKit
import Combine

// MARK: - View model

final class GameVM: ObservableObject {
    @Published var score = 0
    @Published var connected = false
    @Published var aim: Double = 0
    @Published var playing = false
    @Published var goalFlash = false

    let ws = WebSocketClient()
    let motion = MotionManager()
    private let impact = UIImpactFeedbackGenerator(style: .medium)
    private let notify = UINotificationFeedbackGenerator()
    var animal = "🦊"
    private var bag = Set<AnyCancellable>()

    init() {
        ws.onScore = { [weak self] v in self?.score = v }
        ws.onGoal  = { [weak self] in self?.celebrate() }
        motion.onAim  = { [weak self] d in self?.aim = d; self?.ws.sendAim(d) }
        motion.onKick = { [weak self] p in self?.ws.sendKick(p); self?.impact.impactOccurred() }
        // mirror websocket connection state
        ws.$connected.receive(on: DispatchQueue.main).assign(to: &$connected)
    }

    func start(host: String) {
        impact.prepare(); notify.prepare()
        ws.connect(host: host)
        motion.start()
        playing = true
        ws.sendStart()
        ws.sendPick(animal)
    }

    func pick(_ a: String) { animal = a; ws.sendPick(a) }
    func shoot()           { ws.sendKick(0.8); impact.impactOccurred() }
    func calibrate()       { motion.calibrate() }

    private func celebrate() {
        notify.notificationOccurred(.success)
        goalFlash = true
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) { self.goalFlash = false }
    }
}

// MARK: - Theme

enum Theme {
    static let night  = Color(red: 0.04, green: 0.09, blue: 0.13)
    static let mint   = Color(red: 0.37, green: 0.92, blue: 0.83)
    static let coral  = Color(red: 1.00, green: 0.42, blue: 0.51)
    static let gold   = Color(red: 1.00, green: 0.88, blue: 0.54)
    static let cream  = Color(red: 0.96, green: 0.97, blue: 0.95)
    static func rounded(_ s: CGFloat, _ w: Font.Weight = .semibold) -> Font {
        .system(size: s, weight: w, design: .rounded)
    }
}

// MARK: - Content

struct ContentView: View {
    @StateObject private var vm = GameVM()
    @State private var host = ""
    @AppStorage("lastHost") private var savedHost = ""
    private let animals = ["🦊","🐼","🐱","🐧","🐯","🐶"]

    var body: some View {
        ZStack {
            LinearGradient(colors: [Color(red:0.11,green:0.23,blue:0.32), Theme.night],
                           startPoint: .top, endPoint: .bottom).ignoresSafeArea()
            RadialGradient(colors: [Theme.gold.opacity(0.18), .clear],
                           center: .top, startRadius: 0, endRadius: 320)
                .ignoresSafeArea()

            if vm.playing { playScreen } else { setupScreen }

            if vm.goalFlash {
                Text("GOAL! ⚽️").font(Theme.rounded(46, .bold)).foregroundStyle(Theme.mint)
                    .transition(.scale.combined(with: .opacity))
            }
        }
        .animation(.spring(response: 0.3), value: vm.goalFlash)
        .onAppear { host = savedHost }
    }

    // ----- setup -----
    private var setupScreen: some View {
        VStack(spacing: 18) {
            Text("FLOODLIGHT FRIENDLIES").font(Theme.rounded(12, .bold))
                .tracking(3).foregroundStyle(Theme.mint.opacity(0.85))
            Text("Animal Soccer").font(Theme.rounded(32, .bold)).foregroundStyle(Theme.cream)
            Text("You’re the striker. Tilt to aim, flick to shoot.")
                .font(Theme.rounded(15, .medium)).foregroundStyle(Theme.cream.opacity(0.7))
                .multilineTextAlignment(.center)

            VStack(alignment: .leading, spacing: 8) {
                Text("MAC ADDRESS (shown in Terminal)").font(Theme.rounded(11, .semibold))
                    .tracking(1.5).foregroundStyle(Theme.cream.opacity(0.5))
                TextField("e.g. 192.168.1.24", text: $host)
                    .keyboardType(.numbersAndPunctuation)
                    .autocorrectionDisabled().textInputAutocapitalization(.never)
                    .font(Theme.rounded(18, .semibold)).foregroundStyle(Theme.cream)
                    .padding(14)
                    .background(RoundedRectangle(cornerRadius: 14).fill(Color.black.opacity(0.28)))
                    .overlay(RoundedRectangle(cornerRadius: 14).stroke(Theme.mint.opacity(0.25)))
            }

            Text("CHOOSE YOUR ANIMAL").font(Theme.rounded(11, .semibold))
                .tracking(1.5).foregroundStyle(Theme.cream.opacity(0.5))
            HStack(spacing: 8) {
                ForEach(animals, id: \.self) { a in
                    Text(a).font(.system(size: 28))
                        .frame(maxWidth: .infinity).frame(height: 52)
                        .background(RoundedRectangle(cornerRadius: 14)
                            .fill(vm.animal == a ? Theme.coral.opacity(0.18) : Color.white.opacity(0.06)))
                        .overlay(RoundedRectangle(cornerRadius: 14)
                            .stroke(vm.animal == a ? Theme.coral : .clear, lineWidth: 2))
                        .onTapGesture { vm.pick(a) }
                }
            }

            Button {
                savedHost = host
                vm.start(host: host)
            } label: {
                Text("Start playing").font(Theme.rounded(20, .bold)).foregroundStyle(Theme.night)
                    .frame(maxWidth: .infinity).padding(.vertical, 16)
                    .background(LinearGradient(colors: [Color(red:0.48,green:0.94,blue:0.86), Theme.mint],
                                               startPoint: .top, endPoint: .bottom))
                    .clipShape(RoundedRectangle(cornerRadius: 18))
            }
            .disabled(host.isEmpty)
            .opacity(host.isEmpty ? 0.5 : 1)
        }
        .padding(24)
        .background(card)
        .padding(20)
    }

    // ----- play -----
    private var playScreen: some View {
        VStack(spacing: 18) {
            HStack(alignment: .firstTextBaseline) {
                VStack(alignment: .leading) {
                    Text("GOALS").font(Theme.rounded(11, .semibold)).tracking(1.5)
                        .foregroundStyle(Theme.cream.opacity(0.5))
                    Text("\(vm.score)").font(Theme.rounded(44, .bold)).foregroundStyle(Theme.mint)
                }
                Spacer()
                Text(vm.animal).font(.system(size: 36))
            }

            // tilt meter
            GeometryReader { geo in
                ZStack {
                    RoundedRectangle(cornerRadius: 18).fill(Color.black.opacity(0.28))
                    Rectangle().fill(Color.white.opacity(0.18)).frame(width: 2)
                    Circle().fill(LinearGradient(colors: [Theme.gold, Color(red:0.96,green:0.78,blue:0.31)],
                                                 startPoint: .top, endPoint: .bottom))
                        .frame(width: 46, height: 46)
                        .overlay(Text("🎯").font(.system(size: 22)))
                        .offset(x: CGFloat(vm.aim) * (geo.size.width/2 - 26))
                }
            }
            .frame(height: 60)

            Text("Tilt **left / right** to aim").font(Theme.rounded(15, .medium))
                .foregroundStyle(Theme.cream.opacity(0.82))
            Text("Flick the phone forward to shoot").font(Theme.rounded(13, .regular))
                .foregroundStyle(Theme.cream.opacity(0.5))

            Button { vm.shoot() } label: {
                Text("Shoot (or flick!)").font(Theme.rounded(20, .bold)).foregroundStyle(Theme.night)
                    .frame(maxWidth: .infinity).padding(.vertical, 16)
                    .background(LinearGradient(colors: [Color(red:1,green:0.54,blue:0.61), Theme.coral],
                                               startPoint: .top, endPoint: .bottom))
                    .clipShape(RoundedRectangle(cornerRadius: 18))
            }

            HStack(spacing: 8) {
                Circle().fill(vm.connected ? Theme.mint : Color.gray).frame(width: 10, height: 10)
                Text(vm.connected ? "Connected" : "Connecting…")
                    .font(Theme.rounded(13, .semibold)).foregroundStyle(Theme.cream.opacity(0.7))
            }
            Button("Re-center aim") { vm.calibrate() }
                .font(Theme.rounded(13, .medium)).foregroundStyle(Theme.gold)
        }
        .padding(24)
        .background(card)
        .padding(20)
    }

    private var card: some View {
        RoundedRectangle(cornerRadius: 28)
            .fill(.ultraThinMaterial)
            .overlay(RoundedRectangle(cornerRadius: 28).stroke(Theme.mint.opacity(0.22)))
    }
}

#Preview { ContentView() }
