import Foundation
import CoreMotion

/// Reads device motion to produce an aim value (-1...1) and detect forward "flick" kicks.
final class MotionManager: ObservableObject {
    @Published var aim: Double = 0          // smoothed, calibrated, -1...1

    private let mm = CMMotionManager()
    private var zeroRoll: Double = 0        // calibration baseline
    private var lastKick: TimeInterval = 0
    private var lastAimSent: TimeInterval = 0

    var onAim: ((Double) -> Void)?
    var onKick: ((Double) -> Void)?

    // tuning
    private let tiltRange = 0.7              // radians of roll for full deflection (~40°)
    private let kickThreshold = 1.5          // g of user acceleration to count as a flick
    private let kickCooldown: TimeInterval = 0.34

    func start() {
        guard mm.isDeviceMotionAvailable else { return }
        mm.deviceMotionUpdateInterval = 1.0 / 60.0
        mm.startDeviceMotionUpdates(to: .main) { [weak self] motion, _ in
            guard let self, let m = motion else { return }
            self.process(m)
        }
        // capture neutral after a brief settle
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) { [weak self] in
            self?.calibrate()
        }
    }

    func stop() { mm.stopDeviceMotionUpdates() }

    func calibrate() {
        if let m = mm.deviceMotion { zeroRoll = m.attitude.roll }
    }

    private func process(_ m: CMDeviceMotion) {
        let now = Date().timeIntervalSince1970

        // ----- aim from roll (tilt left/right) -----
        var d = (m.attitude.roll - zeroRoll) / tiltRange
        d = max(-1, min(1, d))
        aim = aim + (d - aim) * 0.35                       // smoothing
        if now - lastAimSent > 0.025 {
            lastAimSent = now
            onAim?(Double((aim * 1000).rounded() / 1000))
        }

        // ----- kick from forward flick (user acceleration spike) -----
        let a = m.userAcceleration
        let mag = sqrt(a.x*a.x + a.y*a.y + a.z*a.z)
        if mag > kickThreshold, now - lastKick > kickCooldown {
            lastKick = now
            let power = max(0, min(1, (mag - kickThreshold) / 2.0))
            onKick?(power)
        }
    }
}
