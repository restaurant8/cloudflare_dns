import Foundation

/// Minimal JSON WebSocket client for the Animal Soccer relay server.
/// Connects to:  ws://<host>:3001/?role=controller
final class WebSocketClient: NSObject, ObservableObject, URLSessionWebSocketDelegate {
    @Published var connected = false

    private var task: URLSessionWebSocketTask?
    private var session: URLSession!
    private var host = ""
    private var port = 3001
    private var shouldReconnect = false

    /// callbacks
    var onScore: ((Int) -> Void)?
    var onGoal: (() -> Void)?

    override init() {
        super.init()
        session = URLSession(configuration: .default, delegate: self, delegateQueue: .main)
    }

    func connect(host: String, port: Int = 3001) {
        self.host = host.trimmingCharacters(in: .whitespaces)
        self.port = port
        self.shouldReconnect = true
        open()
    }

    private func open() {
        guard let url = URL(string: "ws://\(host):\(port)/?role=controller") else { return }
        task = session.webSocketTask(with: url)
        task?.resume()
        receive()
    }

    func disconnect() {
        shouldReconnect = false
        task?.cancel(with: .goingAway, reason: nil)
        task = nil
        connected = false
    }

    // MARK: send
    func send(_ dict: [String: Any]) {
        guard let task = task,
              let data = try? JSONSerialization.data(withJSONObject: dict),
              let str = String(data: data, encoding: .utf8) else { return }
        task.send(.string(str)) { _ in }
    }
    func sendAim(_ d: Double)            { send(["t": "aim", "d": d]) }
    func sendKick(_ power: Double)       { send(["t": "kick", "p": power]) }
    func sendPick(_ animal: String)      { send(["t": "pick", "a": animal]) }
    func sendStart()                     { send(["t": "start"]) }

    // MARK: receive loop
    private func receive() {
        task?.receive { [weak self] result in
            guard let self else { return }
            switch result {
            case .failure:
                self.connected = false
                if self.shouldReconnect {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) { self.open() }
                }
            case .success(let message):
                if case let .string(text) = message { self.handle(text) }
                self.receive()
            }
        }
    }

    private func handle(_ text: String) {
        guard let data = text.data(using: .utf8),
              let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let t = obj["t"] as? String else { return }
        switch t {
        case "score": if let v = obj["v"] as? Int { onScore?(v) }
        case "goal":  onGoal?()
        default: break
        }
    }

    // MARK: delegate
    func urlSession(_ s: URLSession, webSocketTask: URLSessionWebSocketTask,
                    didOpenWithProtocol p: String?) {
        connected = true
    }
    func urlSession(_ s: URLSession, webSocketTask: URLSessionWebSocketTask,
                    didCloseWith code: URLSessionWebSocketTask.CloseCode, reason: Data?) {
        connected = false
    }
}
