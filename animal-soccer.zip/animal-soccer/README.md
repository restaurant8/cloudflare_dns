# 🦊 Animal Soccer — phone-motion soccer arcade

Your Mac is the big screen; your phone is the motion controller. Tilt to aim,
flick the phone forward to shoot, and bury it past the sliding keeper. Two ways
to play the controller:

- **Web version** — any phone, just a browser (iOS + Android)
- **iOS app version** — native SwiftUI controller, smoother motion + real haptics

Both talk to the same local server. Everything runs on your own machine/LAN —
nothing goes to the internet.

---

## 1) Run the server (required for both versions)

You need [Node.js](https://nodejs.org) (v18+). Then:

```bash
cd animal-soccer
npm install
npm start
```

You'll see something like:

```
🦊  Animal Soccer is live
  Big screen (open on this Mac):  https://localhost:3000
  Web controller:                 https://192.168.1.24:3000/controller
  Native iOS app connects to:     ws://192.168.1.24:3001/?role=controller
```

Open **https://localhost:3000** on your Mac and put that window full-screen.
(Your browser will warn about the self-signed certificate — click *Advanced ▸
Proceed*. This is expected and safe for a local app.)

---

## 2A) Play with the WEB controller (no install)

1. Make sure your phone is on the **same Wi-Fi** as the Mac.
2. On the phone, **scan the QR code** shown on the big screen (or type the
   `…/controller` URL into Safari/Chrome).
3. Tap **Continue / Proceed** to accept the local certificate.
4. Pick your animal, tap **Start playing**, and allow motion access when asked.
5. Tilt left/right to aim, **flick the phone forward** to shoot.

> **iPhone note:** motion sensors only work over HTTPS and after you tap
> *Start* — that's why the page asks permission on the button press. If you ever
> denied it, re-enable under *Settings ▸ Safari ▸ Motion & Orientation Access*.

No phone? You can test on the Mac with the keyboard:
`←` `→` aim · `Space` shoot · `Enter` start · `1`–`6` change animal.

---

## 2B) Play with the iOS APP

See **`ios/README.md`** for the 5-minute Xcode setup. In short: open the project,
set your Apple ID as the signing team, run it on your iPhone, type the Mac's IP
address (the one shown in Terminal / on the big screen), pick an animal, and play.

The native app needs no certificate juggling and gives you crisp haptic feedback
on every goal.

---

## How it works

```
phone (tilt + flick)  ──ws──▶  Node relay  ──ws──▶  Mac big screen (Canvas game)
        ▲                                                   │
        └──────────────── goal! (haptics, score) ◀──────────┘
```

- `server.js` — HTTPS+WSS on :3000 (screen + web controller), plain WS on :3001 (iOS app). Pure message relay; the game logic lives on the big screen.
- `public/display.html` — the game: perspective turf, sliding netted goal, animated animal striker, combo scoring, 60-second matches.
- `public/controller.html` — the web phone controller.
- `ios/` — the native SwiftUI controller.

## Tuning

Most feel is controlled by a few constants:

- **Web controller** (`public/controller.html`): `±35°` tilt range, kick threshold `14` m/s², cooldown `340` ms.
- **iOS** (`MotionManager.swift`): `tiltRange`, `kickThreshold`, `kickCooldown`.
- **Game** (`public/display.html`, `shoot()` / `update()`): shot speed, goal speed ramp, match length (`timeLeft`).

## Troubleshooting

- **Phone can't reach the server** — same Wi-Fi? Some guest/hotel/office networks
  enable *AP isolation* which blocks device-to-device traffic; use a phone hotspot
  or home Wi-Fi instead.
- **No motion on iPhone (web)** — you must use the **https** URL and tap *Start* to
  grant permission.
- **macOS firewall prompt** — allow `node` to accept incoming connections.
