/* Animal Soccer — local host server
 * - HTTPS + WSS on PORT_HTTPS  : serves the big-screen display + the web phone controller
 * - Plain HTTP + WS on PORT_WS : endpoint for the native iOS controller app (no TLS needed)
 * Both websocket servers feed one relay hub: controller messages -> display, display messages -> controllers.
 */
const fs = require('fs');
const path = require('path');
const os = require('os');
const http = require('http');
const https = require('https');
const express = require('express');
const { WebSocketServer } = require('ws');
const QRCode = require('qrcode');
const selfsigned = require('selfsigned');

const PORT_HTTPS = 3000; // display + web controller (TLS required for phone motion sensors)
const PORT_WS = 3001;    // native iOS app controller (ws://)

// ---- find this machine's LAN IPv4 (prefer 192.168 / 10 / 172) ----
function getLanIp() {
  const ifaces = os.networkInterfaces();
  const all = [];
  for (const name of Object.keys(ifaces)) {
    for (const net of ifaces[name] || []) {
      if (net.family === 'IPv4' && !net.internal) all.push(net.address);
    }
  }
  const pref = all.find(a => a.startsWith('192.168.')) ||
               all.find(a => a.startsWith('10.')) ||
               all.find(a => a.startsWith('172.')) || all[0];
  return pref || '127.0.0.1';
}
const LAN_IP = getLanIp();

// ---- self-signed cert (generated once, reused) ----
function loadCert() {
  const keyPath = path.join(__dirname, 'certs', 'key.pem');
  const certPath = path.join(__dirname, 'certs', 'cert.pem');
  if (fs.existsSync(keyPath) && fs.existsSync(certPath)) {
    return { key: fs.readFileSync(keyPath), cert: fs.readFileSync(certPath) };
  }
  const attrs = [{ name: 'commonName', value: LAN_IP }];
  const pems = selfsigned.generate(attrs, {
    days: 825,
    keySize: 2048,
    algorithm: 'sha256',
    extensions: [{
      name: 'subjectAltName',
      altNames: [
        { type: 2, value: 'localhost' },
        { type: 7, ip: LAN_IP },
        { type: 7, ip: '127.0.0.1' },
      ],
    }],
  });
  fs.writeFileSync(keyPath, pems.private);
  fs.writeFileSync(certPath, pems.cert);
  return { key: pems.private, cert: pems.cert };
}

// ---- relay hub ----
let display = null;            // single big screen
const controllers = new Set(); // one or more phones / apps

function send(ws, obj) {
  if (ws && ws.readyState === 1) {
    try { ws.send(JSON.stringify(obj)); } catch (_) {}
  }
}
function broadcastControllers(obj) { controllers.forEach(c => send(c, obj)); }

function attach(ws, req) {
  let role = 'controller';
  try {
    const u = new URL(req.url, 'http://x');
    if (u.searchParams.get('role') === 'display') role = 'display';
  } catch (_) {}

  if (role === 'display') {
    display = ws;
    send(ws, { t: 'hello', role: 'display' });
    send(ws, { t: 'ctrl', connected: controllers.size > 0 });
  } else {
    controllers.add(ws);
    send(ws, { t: 'hello', role: 'controller' });
    send(display, { t: 'ctrl', connected: true });
  }

  ws.on('message', (data) => {
    let msg; try { msg = JSON.parse(data); } catch { return; }
    if (role === 'controller') send(display, msg);
    else broadcastControllers(msg);
  });
  ws.on('close', () => {
    if (role === 'display') { if (display === ws) display = null; }
    else { controllers.delete(ws); send(display, { t: 'ctrl', connected: controllers.size > 0 }); }
  });
  ws.on('error', () => {});
}

// ---- express static + info ----
const app = express();
app.use(express.static(path.join(__dirname, 'public')));
app.get('/', (_req, res) => res.sendFile(path.join(__dirname, 'public', 'display.html')));
app.get('/controller', (_req, res) => res.sendFile(path.join(__dirname, 'public', 'controller.html')));
app.get('/info', async (_req, res) => {
  const url = `https://${LAN_IP}:${PORT_HTTPS}/controller`;
  let qr = '';
  try { qr = await QRCode.toDataURL(url, { margin: 1, width: 360 }); } catch (_) {}
  res.json({ url, qr, lanIp: LAN_IP, wsPort: PORT_WS });
});

// ---- start HTTPS (display + web controller + WSS) ----
const httpsServer = https.createServer(loadCert(), app);
const wssSecure = new WebSocketServer({ server: httpsServer });
wssSecure.on('connection', attach);
httpsServer.listen(PORT_HTTPS, '0.0.0.0', () => {
  console.log('\n  🦊  Animal Soccer is live\n');
  console.log('  Big screen (open on this Mac):');
  console.log(`     https://localhost:${PORT_HTTPS}\n`);
  console.log('  Web controller (scan the on-screen QR, or open on your phone):');
  console.log(`     https://${LAN_IP}:${PORT_HTTPS}/controller`);
  console.log('     (accept the self-signed certificate warning the first time)\n');
  console.log('  Native iOS app connects to:');
  console.log(`     ws://${LAN_IP}:${PORT_WS}/?role=controller\n`);
});

// ---- start plain WS (native iOS app) ----
const httpServer = http.createServer((_req, res) => { res.writeHead(426); res.end('Use WebSocket'); });
const wsPlain = new WebSocketServer({ server: httpServer });
wsPlain.on('connection', attach);
httpServer.listen(PORT_WS, '0.0.0.0');
